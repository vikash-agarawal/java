package com.capgemini.salesmanagement.util;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;

public class CollectionUtil {
	private static HashMap<Integer,Sale> sales=new HashMap<>();
	public static HashMap<Integer,Sale> getCollection()
	{
		return sales;
	}
	public static void setSales(HashMap<Integer, Sale> sales) {
		CollectionUtil.sales = sales;
	}
	
}
