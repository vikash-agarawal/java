package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exception.InvalidProductCatagoryException;
import com.capgemini.salesmanagement.exception.InvalidProductCodeException;
import com.capgemini.salesmanagement.exception.InvalidProductName;
import com.capgemini.salesmanagement.exception.InvalidProductPriceException;
import com.capgemini.salesmanagement.exception.InvalidProductquantityException;

public interface ISaleService {
	public HashMap<Integer,Sale> insertSaleDetails(Sale sale);
	public boolean validateProductcode(int productId) throws InvalidProductCodeException;
	public boolean validatequantity(int qty) throws InvalidProductquantityException;
	public boolean validateProductCat(String prodCat) throws InvalidProductCatagoryException;
	public boolean validateProductName(String prodName) throws InvalidProductName;
	public boolean validateProductPrice(float price) throws InvalidProductPriceException;
}
