package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class SaleService implements ISaleService {
	ISaleDAO dao=new SaleDAO();
	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		// TODO Auto-generated method stub
		return dao.insertSalesDetails(sale);
	}

	@Override
	public boolean validateProductcode(int productId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validatequantity(int qty) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateProductName(String prodName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateProductPrice(float price) {
		// TODO Auto-generated method stub
		return false;
	}

}
