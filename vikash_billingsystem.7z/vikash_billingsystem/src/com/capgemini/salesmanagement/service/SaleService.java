package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exception.InvalidProductCatagoryException;
import com.capgemini.salesmanagement.exception.InvalidProductCodeException;
import com.capgemini.salesmanagement.exception.InvalidProductName;
import com.capgemini.salesmanagement.exception.InvalidProductPriceException;
import com.capgemini.salesmanagement.exception.InvalidProductquantityException;

public class SaleService implements ISaleService {
	ISaleDAO dao=new SaleDAO();
	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		// TODO Auto-generated method stub
		return dao.insertSalesDetails(sale);
	}

	@Override
	public boolean validateProductcode(int productId) throws InvalidProductCodeException {
		// TODO Auto-generated method stub
		if(productId==1001 || productId==1002 || productId==1003 || productId==1004)
		{
			return true;
		}
		else
		{
			throw new InvalidProductCodeException("product code between 1001,1002"
				+ ",1003,1004");
		}
	}

	@Override
	public boolean validatequantity(int qty) throws InvalidProductquantityException {
		// TODO Auto-generated method stub
		if(qty>5)
		{
			return true;
		}
		else
		{
			throw new InvalidProductquantityException("quantity sholud be greater than 5");
		}
	}

	@Override
	public boolean validateProductCat(String prodCat) throws InvalidProductCatagoryException {
		// TODO Auto-generated method stub
		if(prodCat.equals("Electronics") || prodCat.equals("Toys"))
		{
			return true;
		}
		else
		{
			throw new InvalidProductCatagoryException("catagory shloud be electronics or Toys");
		}
	}

	@Override
	public boolean validateProductName(String prodName) throws InvalidProductName {
		// TODO Auto-generated method stub
		if(prodName.equals("TV") || prodName.equals("Smart Phone") || prodName.equals("Video Game")
				|| prodName.equals("Soft Toy") || prodName.equals("Telescope") ||
				prodName.equals("Barbee Doll"))
		{
			return true;
		}
		else
		{
			throw new InvalidProductName("product description in is given format");
		}
	}

	@Override
	public boolean validateProductPrice(float price) throws InvalidProductPriceException {
		// TODO Auto-generated method stub
		if(price>200)
		{
			return true;
		}
		else
		{
			throw new InvalidProductPriceException("price sholud greater than 200");
		}
	}

}
