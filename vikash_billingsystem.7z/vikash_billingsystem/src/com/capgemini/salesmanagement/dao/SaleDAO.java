package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {
	CollectionUtil util=new CollectionUtil();
	HashMap<Integer,Sale> sales;
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		sales=CollectionUtil.getCollection();
		sale.setLinetotal(sale.getLinetotal()*sale.getQuantity());
		sales.put(sale.getSaleId(), sale);
		CollectionUtil.setSales(sales);
		return sales;
	}
	
}
