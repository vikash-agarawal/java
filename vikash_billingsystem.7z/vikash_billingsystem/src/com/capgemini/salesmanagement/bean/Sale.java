package com.capgemini.salesmanagement.bean;

import java.time.LocalDate;

public class Sale {
	private int SaleId;
	private int prodCode;
	private String productName;
	private String Catagory;
	private LocalDate saleDate;
	private int quantity;
	private float linetotal;
	public Sale(int saleId, int prodCode, String productName, String catagory, LocalDate saleDate, int quantity,
			float linetotal) {
		super();
		SaleId = saleId;
		this.prodCode = prodCode;
		this.productName = productName;
		Catagory = catagory;
		this.saleDate = saleDate;
		this.quantity = quantity;
		this.linetotal = linetotal;
	}
	public int getSaleId() {
		return SaleId;
	}
	public void setSaleId(int saleId) {
		SaleId = saleId;
	}
	public int getProdCode() {
		return prodCode;
	}
	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCatagory() {
		return Catagory;
	}
	public void setCatagory(String catagory) {
		Catagory = catagory;
	}
	public LocalDate getSaleDate() {
		return saleDate;
	}
	public void setSaleDate(LocalDate saleDate) {
		this.saleDate = saleDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getLinetotal() {
		return linetotal;
	}
	public void setLinetotal(float linetotal) {
		this.linetotal = linetotal;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Catagory == null) ? 0 : Catagory.hashCode());
		result = prime * result + SaleId;
		result = prime * result + Float.floatToIntBits(linetotal);
		result = prime * result + prodCode;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + quantity;
		result = prime * result + ((saleDate == null) ? 0 : saleDate.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sale other = (Sale) obj;
		if (Catagory == null) {
			if (other.Catagory != null)
				return false;
		} else if (!Catagory.equals(other.Catagory))
			return false;
		if (SaleId != other.SaleId)
			return false;
		if (Float.floatToIntBits(linetotal) != Float.floatToIntBits(other.linetotal))
			return false;
		if (prodCode != other.prodCode)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (quantity != other.quantity)
			return false;
		if (saleDate == null) {
			if (other.saleDate != null)
				return false;
		} else if (!saleDate.equals(other.saleDate))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Sale [SaleId=" + SaleId + ", \nprodCode=" + prodCode + ", \nproductName=" + productName + ", \nCatagory="
				+ Catagory + ", saleDate=" + saleDate + ", quantity=" + quantity + ", linetotal=" + linetotal + "]";
	}
	
}
