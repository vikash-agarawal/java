package com.capgemini.salesmanagement.exception;

public class InvalidProductName extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductName(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
