package com.capgemini.salesmanagement.exception;

public class InvalidProductPriceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductPriceException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
