package com.capgemini.salesmanagement.exception;

public class InvalidProductquantityException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductquantityException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
