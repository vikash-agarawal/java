package com.capgemini.salesmanagement.exception;

public class InvalidProductCatagoryException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductCatagoryException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
