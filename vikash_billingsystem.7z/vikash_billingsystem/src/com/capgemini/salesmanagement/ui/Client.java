package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ISaleService service=new SaleService();
		Scanner scanner=new Scanner(System.in);
		while(true)
		{
			System.out.println("\nenter 1 for bill calculation"
					+ "\n2 for exit \n enter your choice::");
			int choice=scanner.nextInt();
			switch(choice)
			{
			case 1: System.out.println("enter product code");
			        int prodcode=scanner.nextInt();
			        System.out.println("enter the quantity");
			        int qty=scanner.nextInt();
			        System.out.println("enter product catagory");
			        String cat=scanner.next();
			        System.out.println("enter product name");
			        String prodname=scanner.next();
			        System.out.println("enter product description");
			        String proddes=scanner.next();
			        scanner.nextLine();
			        System.out.println("enter product price");
			        float price=scanner.nextFloat();
			        LocalDate saledate=LocalDate.now();
			        int saleid=(int) (Math.random()*1000)+1;
			        Sale sale=new Sale(saleid,prodcode,prodname,cat,saledate,qty,price);
			        try
			        {
			        	if(service.validateProductcode(prodcode) ||
			        			service.validateProductCat(cat) ||
			        			service.validateProductName(proddes) ||
			        			service.validateProductPrice(price) ||
			        			service.validatequantity(qty))
			        	{
			        		System.out.println(service.insertSaleDetails(sale));
			        	}
			        }
			        catch(Exception e)
			        {
			        	System.out.println(e.getMessage());
			        }
			        	
			        break;
			case 2: System.exit(0);      
			}
		}
	}

}
