import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class TestInheritanceDemo {
	public static void main(String[] args)
	{
		Emp rahul = new Emp();
		rahul.setEmpName("Rahul chauhan");
		rahul.setEmpSal(60000);
		Manager vaishali = new Manager();
		vaishali.setEmpName("Vaishali");
		vaishali.setEmpSal(600);
		vaishali.setDeptName("java");
		
		
		EntityManager em1=JPAUtil.getEntityManager();
		EntityTransaction tran = em1.getTransaction();
		tran.begin();
		em1.persist(rahul);
		em1.persist(vaishali);
		tran.commit();
		System.out.println("data inserted");
		
	}

}
