/**
 * 
 */
package jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import jdbc.util.DBMS;

class Update {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter empid:");
		int eid = sc.nextInt();
		/*System.out.println("Enter empName:");
		sc.nextLine();
		String enm = sc.nextLine();
		System.out.println("Enter empsal:");
		float esal = sc.nextFloat();*/
		try {
			Connection con = DBMS.getCon();
			String insertQry = "update emp1 set emp_name=?, emp_sal=? where emp_id=?";
			PreparedStatement pst = con.prepareStatement(insertQry);
			pst.setString(1, "sumit");
			pst.setInt(2,30000);
			pst.setInt(3, eid);
			//pst.setFloat(3, esal);
			int data = pst.executeUpdate();
			System.out.println("Data is Updated" + data);

		} catch (SQLException e) {
			e.printStackTrace();

		}

		catch (IOException e) {
			e.printStackTrace();
		}

	}

}

