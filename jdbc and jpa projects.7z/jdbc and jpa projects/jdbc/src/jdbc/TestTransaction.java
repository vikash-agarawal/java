package jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import jdbc.util.DBMS;

public class TestTransaction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
		con=DBMS.getCon();
		con.setAutoCommit(false);
		String update1="update emp1 set emp_name= 'vaishali'" +
				"where emp_id=111";
		String update2="update emp1 set emp_sal=300" +
				"where emp_id=112";
		Statement st = con.createStatement();
		st.addBatch(update1);
		st.addBatch(update2);
		int arr[] = st.executeBatch();
		con.commit();
		System.out.println("update success");
	}
		catch (SQLException | IOException e)
		{
			try {
				con.rollback();
			}
			catch (SQLException e1)
			{
			e1.printStackTrace();
		}
			e.printStackTrace();

}
}
}
