package com.cg.prog7_6.eis.pl;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.prog7_6.eis.bean.Employee;
import com.cg.prog7_6.eis.exception.EmployeeException;
import com.cg.prog7_6.eis.service.Service;

public class Main {

	public static void main(String[] args) throws EmployeeException{
		// TODO Auto-generated method stub
		Service s = new Service();
		int choice=0;
		HashMap<Integer,Employee> map = new HashMap<>();
		Scanner scanner = new Scanner(System.in);
			while (true) {
				
				System.out.println(
						"1. for add details\n 2. for get details based on insurance scheme\n 3. for delete an employee\n 4. for sort employee based on salary \n 5. for exit");
				System.out.println();
				if(scanner.hasNextInt())
					choice= scanner.nextInt();
				switch (choice) {
				case 1:
					Employee e;
					e=s.setdetails();
					map.put(e.getId(),e);
					break;
				case 2:
					System.out.println("enter insurance scheme");
					String insch = scanner.next();
					s.getdetails(insch, map);
					break;
				case 3:
					System.out.println("enter the employee id of the employee whom you want to remove");
					int id = scanner.nextInt();
					s.removeEmployee(id, map);
					break;
				case 4:
					s.Sort(map);
					break;
				case 5:
					System.exit(0);
					
					
				}
			}
		}
	}
