package com.cg.prog7_6.eis.service;

import java.util.HashMap;

import com.cg.prog7_6.eis.bean.Employee;
import com.cg.prog7_6.eis.exception.EmployeeException;

public interface Employeeservices {
	public Employee setdetails() throws EmployeeException;

	public void findscheme(int salary, String designation, Employee e);

	public void getdetails(String str, HashMap<Integer, Employee> map);

	public void removeEmployee(int id, HashMap<Integer, Employee> map);

	public void Sort(HashMap<Integer, Employee> map);
}
