/**
 * 
 */
package com.cg.prog2_2.bean;

/**
 * @author VIKAAGRA
 *
 */
public class Number {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		if(a>=0)
		{
			System.out.println("number is positive");
		}
		else
		{
			System.out.println("number is negative");
		}
	}

}
