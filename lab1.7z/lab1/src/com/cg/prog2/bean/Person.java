package com.cg.prog2.bean;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("First name: Divya");
		System.out.println("last name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 66");
	}
}
