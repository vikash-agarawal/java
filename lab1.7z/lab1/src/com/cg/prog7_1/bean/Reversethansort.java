package com.cg.prog7_1.bean;
import java.util.*;
public class Reversethansort {
	public String[] reverseArray(int[] intArray) {
		String strArray[] = new String[intArray.length];
		StringBuilder sb1 = new StringBuilder();
		for (int i = 0; i < intArray.length; i++) {
			strArray[i] = String.valueOf(intArray[i]);
			sb1.append(strArray[i]);
			strArray[i] = sb1.reverse().toString();
			sb1.delete(0, intArray.length);
		}
		Arrays.sort(strArray);
		return strArray; 	
	}
}