package com.cg.prog7_1.bean;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Scanner sc=new Scanner(System.in);
          int a[]=new int[4];
          String d[]=new String[4];
          Reversethansort s1=new Reversethansort();
          System.out.println("Enter the no of the elements of the array");
          int n=sc.nextInt();
          int i;
          System.out.println("Enter the elements of the array");
          for(i=0;i<n;i++)
          {a[i]=sc.nextInt();
          
          }
          sc.close();
         d=s1.reverseArray(a);
          for(String j:d)
        	  System.out.println(j);
	}

}
