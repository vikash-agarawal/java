package com.cg.prog2_4.bean;

public class Personmobmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personmob obj=new Personmob("Divya","Bharathi","F","1234565467");
		obj.print();
	}

}
