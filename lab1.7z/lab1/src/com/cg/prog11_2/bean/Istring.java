package com.cg.prog11_2.bean;

@FunctionalInterface
public interface Istring {
	public void space(java.lang.String string);
	

}