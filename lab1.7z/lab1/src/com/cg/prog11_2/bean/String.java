package com.cg.prog11_2.bean;

public abstract class String implements Istring {
    public static void main(String[] args) {
	 
    	Istring e = (tring)->{ System.out.println(tring.replace(""," "));};
    	e.space("hai");
}

	private char[] replace(java.lang.String string, java.lang.String string2) {
		// TODO Auto-generated method stub
		return null;
	}
    
}