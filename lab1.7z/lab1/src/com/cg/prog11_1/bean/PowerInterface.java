package com.cg.prog11_1.bean;

public interface PowerInterface {
public double power(double x,double y);
	
}
