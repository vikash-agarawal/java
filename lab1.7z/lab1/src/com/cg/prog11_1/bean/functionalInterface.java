package com.cg.prog11_1.bean;

public @interface functionalInterface {

}
