package com.cg.prog10_1.bean;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestPerson2 {
	@Test
		public void testGetFullName()
		{
		System.out.println("from TestPerson2");
		Person per = new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
		}
	}
