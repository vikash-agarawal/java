package com.cg.prog4_2.bean;

public class Account {
	int balance;
	public Account(int balance)
	{
		this.balance=balance;
	}
	public boolean withdraw(int balance)
	{
		return true;
	}
}