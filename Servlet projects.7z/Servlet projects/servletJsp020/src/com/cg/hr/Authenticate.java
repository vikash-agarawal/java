package com.cg.hr;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Authenticate
 */
@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		// if by get method- then query stream data
		// by post- pickup data
		String uname=request.getParameter("uname");
		String password=request.getParameter("password");
		RequestDispatcher rd=null;
		if(uname.equals("aa") && (password.equals("bb")))
		{
			String fullname="aaaaa";
			request.setAttribute("fullname",fullname );
			rd=request.getRequestDispatcher("/WEB-INF/pages/MainMenu.jsp");
		}
		else
		{
			request.setAttribute("message", "wrong credentialsplease do again");
			rd=request.getRequestDispatcher("/WEB-INF/pages/Login.jsp");
		}
		rd.forward(request, response);
		System.out.println("user name: "+uname);
	}

}
