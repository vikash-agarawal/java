package com.cg.hr.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.service.EmployeeService;
import com.cg.hr.core.service.EmployeeServiceImp;

@WebServlet("*.hr")
public class FrontControlerHr extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService ser;
	
	@Override
	public void init() throws ServletException {
		super.init();
		try {
			ser=new EmployeeServiceImp();
		} catch (Exception e) {
			throw new ServletException("missed srvice referance", e);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=request.getRequestURI();
		String command=getcommand(url);
		RequestDispatcher dispatcher=null;
		String jspName=null;
		String prefix="/WEB-INF/pages/";
		String postfix=".jsp";
		try {
			switch(command)
			{
			case "*":
			case "HomePage":
				jspName="welcome";
				break;
			case "getLoginPage":
				jspName="Login";
				break;
			case "authenticate":
				String uname=request.getParameter("uname");
				String passward=request.getParameter("password");
				if(uname.equals("aa") && passward.equals("aa"))
				{
					HttpSession session=request.getSession(true);  // getSession()
					System.out.println(session.getId());
					session.setAttribute("fullname", "aa aa aaaa");
					jspName="MainMenu";
				}
				else
				{
					request.setAttribute("message", "wrong credentials");
					jspName="Login";
				}
				break;
			case "printlist":
				ArrayList<Employee> emplist=ser.fetchAllEmp();
				System.out.println(emplist);
				request.setAttribute("emplist", emplist);
				jspName="EmpList";
				break;
			case "viewDetails":
				String strempid=request.getParameter("id");
				int empId=Integer.parseInt(strempid);
				Employee emp=ser.getEmpbyEid(empId);
				System.out.println(emp);
				request.setAttribute("emp", emp);
				jspName="EmpDetails";
				break;
			case "LogOut":
				HttpSession session=request.getSession(false);
				session.invalidate();
				jspName="Thanks";
				break;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dispatcher=request.getRequestDispatcher(prefix+jspName+postfix);
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	private String getcommand(String url)
	{
		int idxslash=url.lastIndexOf("/");
		int idxDot=url.lastIndexOf(".");
		if(idxDot<0)
		{
			return "HomePage";
		}
		else
		{
			return url.substring(idxslash+1, idxDot);	
		}
		
	}
}
