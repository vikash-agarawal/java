package com.cg.hr.core.exception;

public class EmpException {

	public EmpException(String string) {
		// TODO Auto-generated constructor stub
		super();
	}

}
