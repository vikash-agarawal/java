package com.cg.hr.core.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.doa.EmployeeDao;
import com.cg.hr.core.doa.EmployeeDaoImpl;

public class EmployeeServiceImp implements EmployeeService {
	EmployeeDao dao = null;
	public EmployeeServiceImp() throws ClassNotFoundException, SQLException
	{
		dao= new EmployeeDaoImpl();
	}


	@Override
	public ArrayList<Employee> fetchAllEmp() throws SQLException {
		// TODO Auto-generated method stub
		return dao.fetchAllEmp();
	}
	@Override
	public Employee getEmpbyEid(int empId) throws SQLException {
		// TODO Auto-generated method stub
		return dao.getEmpbyEid(empId);
	}
}
