package com.cg.hr.core.doa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	//EntityManager em= null;
	//EntityTransaction entityTran=null;
	Connection con = null;
	ArrayList<Employee> emplist =new ArrayList<>();
	public EmployeeDaoImpl() throws ClassNotFoundException, SQLException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "Capgemini123");
		//em=JPAUtil.getEntityManager();
		//entityTran= em.getTransaction();
	}
	@Override
	public ArrayList<Employee> fetchAllEmp() throws SQLException {
		//String selALLQry= " SELECT emps FROM Employee emps";
		//TypedQuery<Employee> tq = em.createQuery(selALLQry,Employee.class);
		//ArrayList<Employee> empList = (ArrayList<Employee>) tq.getResultList();
		Employee emp=null;
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("Select * from  emp1");
			while (rs.next()) {
				int id=rs.getInt("emp_ID");
				String name=rs.getString("emp_Name");
				float sal=rs.getInt("emp_sal");
				emp=new Employee(id,name,sal);
				emplist.add(emp);
			}
		return emplist;
}
	@Override
	public Employee getEmpbyEid(int empId) throws SQLException {
		Employee emp=null;
		String insertQry = "select * from emp1 where emp_id=?";
		PreparedStatement pst = con.prepareStatement(insertQry);
		pst.setInt(1, empId);
		
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			int id=rs.getInt("emp_ID");
			String name=rs.getString("emp_Name");
			float sal=rs.getInt("emp_sal");
			emp=new Employee(id,name,sal);
		}
		return emp;
	}
}