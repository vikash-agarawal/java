package com.cg.hr.core.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.hr.core.beans.*;

public interface EmployeeService {
	 public ArrayList<Employee> fetchAllEmp() throws SQLException;

	Employee getEmpbyEid(int empId) throws SQLException;
	 
}
