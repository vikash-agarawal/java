package com.cg.hr.core.doa;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;

public interface EmployeeDao { 
 public ArrayList<Employee> fetchAllEmp() throws SQLException;
 public Employee getEmpbyEid(int empId) throws SQLException;
}
