package com.cg.ems.ui;
import java.sql.SQLException;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.service.EmployeeService;
import com.cg.hr.core.service.EmployeeServiceImp;

public class TestEmpJpaDemo {
	public static void main(String[] args)
	{

		EmployeeService empSer = null;
		try {
			empSer = new EmployeeServiceImp();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Employee e1 = new Employee();
		//e1.setEmpName("aaa");
		//e1.setEmpSal(8000.0F);
		//Employee e2 = new Employee(555,"Vikas Agrawal",89000.0F,null);
		//Employee ee1=empSer.addEmp(e1);
		//Employee ee2=empSer.addEmp(e2);
		//System.out.println(ee1 + "\n and " + "are inserted");
		//Employee ee = empSer.getEmpbyEid(555);
		//System.out.println(ee);
	    System.out.println("Fetch all Record");
		ArrayList<Employee> eList = null;
		try {
			eList = empSer.fetchAllEmp();
			System.out.println(eList);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*for(Employee tempE: eList)
		{
			System.out.println(tempE.getEmpId()+"\t" + tempE.getEmpName()+"\t"+ tempE.getEmpSal());
		}
		//System.out.println("----------Delete------");
		//Employee deletedEmp = empSer.deleteEmp(112);
		//System.out.println(deletedEmp + "deleted");
		/*System.out.println("-----update-------");
		Employee updatedE=empSer.updateEmp(555, "kaushal", 90000);
		System.out.println("Update..data" + updatedE.getEmpId());
*/

			

		}

}
