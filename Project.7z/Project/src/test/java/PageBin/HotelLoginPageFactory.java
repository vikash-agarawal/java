package PageBin;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class HotelLoginPageFactory {

	WebDriver driver;
	
	//step 1 : identify elements
	@FindBy(name="userName")
	@CacheLookup
	WebElement pfuname;

	//using how class
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfupwd;

	@FindBy(xpath=".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement pfbutton;

	public WebElement getPfuname() {
		return pfuname;
	}

	public void setPfuname(String suname) {
		pfuname.sendKeys(suname);
	}

	public WebElement getPfupwd() {
		return pfupwd;
	}

	public void setPfupwd(String supwd) {
		pfupwd.sendKeys(supwd);
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public void setPfbutton() {
		pfbutton.click();
	}
	
	public HotelLoginPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
