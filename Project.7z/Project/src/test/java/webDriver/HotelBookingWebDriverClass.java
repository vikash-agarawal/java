package webDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HotelBookingWebDriverClass {
	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VIKAAGRA\\Desktop\\BDD\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///C:/Users/VIKAAGRA/Desktop/BDD/hotelbooking.html");
		
		driver.findElement(By.name("userName")).sendKeys("");
		Thread.sleep(1000);
		
		driver.findElement(By.className("btn")).click();
		
		String alertMessage = driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		Thread.sleep(1000);
	    System.out.println("******" + alertMessage);
	    
	    driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);
		driver.findElement(By.name("userPwd")).sendKeys("");
		Thread.sleep(1000);
		
		driver.findElement(By.className("btn")).click();
		
		String alertMessage1 = driver.findElement(By.xpath(".//*[@id='pwdErrMsg']")).getText();
		Thread.sleep(1000);
	    System.out.println("******" + alertMessage1);
	    
	    driver.findElement(By.name("userName")).clear();
		Thread.sleep(1000);
		driver.findElement(By.name("userPwd")).clear();
		Thread.sleep(1000);
	    
		driver.findElement(By.name("userName")).sendKeys("capgemin");
		Thread.sleep(1000);
	    driver.findElement(By.name("userPwd")).sendKeys("capg14");
		Thread.sleep(1000);
		
		driver.findElement(By.className("btn")).click();
		
		String alertMessage2 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage2);
	    
	    driver.findElement(By.name("userName")).clear();
		Thread.sleep(1000);
		driver.findElement(By.name("userPwd")).clear();
		Thread.sleep(1000);
	    
	    driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);
	    driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(1000);
		
		driver.findElement(By.className("btn")).click();
		driver.navigate().to("file:///C:/Users/VIKAAGRA/Desktop/BDD/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
}
}
