package Loginfunctionality;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBin.HotelLoginPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver driver;
	private HotelLoginPageFactory hlpf;  //page factory object
	
	@Given("^User is on hotel Login page$")
	public void user_is_on_hotel_Login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VIKAAGRA\\Desktop\\BDD\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		hlpf = new HotelLoginPageFactory(driver);
		driver.get("file:///C:/Users/VIKAAGRA/Desktop/BDD/login.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Login")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		hlpf.setPfuname("capgemini"); Thread.sleep(1000);
		hlpf.setPfupwd("capg1234");   Thread.sleep(1000);
		hlpf.setPfbutton();
	}

	@Then("^navigate to Hotel Booking page$")
	public void navigate_to_Hotel_Booking_page() throws Throwable {
		driver.navigate().to("file:///C:/Users/VIKAAGRA/Desktop/BDD/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		 hlpf.setPfuname(""); Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
	    hlpf.setPfbutton();
	}

	@Then("^display username alert msg$")
	public void display_username_alert_msg() throws Throwable {
		String alertMessage = driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		Thread.sleep(1000);
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user leaves password blank$")
	public void user_leaves_password_blank() throws Throwable {
		   hlpf.setPfuname("capgemini"); Thread.sleep(1000);
		   hlpf.setPfupwd("");  Thread.sleep(1000);
	}

	@Then("^display password alert msg$")
	public void display_password_alert_msg() throws Throwable {
		String alertMessage = driver.findElement(By.xpath(".//*[@id='pwdErrMsg']")).getText();
		Thread.sleep(1000);
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user entering the all data$")
	public void user_entering_the_all_data() throws Throwable {
		hlpf.setPfuname("capgemini"); Thread.sleep(1000);
		hlpf.setPfupwd("capg12");   Thread.sleep(1000);
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}
}
