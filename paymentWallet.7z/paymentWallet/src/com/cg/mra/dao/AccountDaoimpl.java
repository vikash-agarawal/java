package com.cg.mra.dao;

import java.util.ArrayList;
import java.util.Map;

import com.cg.mra.beans.Account;
import com.cg.mra.beans.Transaction;
import com.cg.mra.beans.util.AccountUtil;

public class AccountDaoimpl implements AccountDao {
	Map<String,Account> accountEntry;
	public AccountDaoimpl() {
		accountEntry=AccountUtil.getAccountMap();
	}
	@Override
	public Account createAccount(Account account) {
		accountEntry.put(account.getWallet().getMobileNO(), account);
		return account;
	}
	@Override
	public double showBalance(String mobileNo) {
		double amount=accountEntry.get(mobileNo).getWallet().getAccountBalance();
		return amount;
	}
	@Override
	public double deposit(String mobileNo, double rechargeamount) {
		Account account=accountEntry.get(mobileNo);
		account.getWallet().setAccountBalance(account.getWallet().getAccountBalance()+rechargeamount);
		return account.getWallet().getAccountBalance();
	}
	@Override
	public double withdrow(String mobileNo, double withdrawamount) {
		Account account=accountEntry.get(mobileNo);
		account.getWallet().setAccountBalance(account.getWallet().getAccountBalance()-withdrawamount);
		return account.getWallet().getAccountBalance();
		
	}
	@Override
	public String fundTransfer(String giverMobileNo, double amount, String gainerMobileNo) {
		Account account=accountEntry.get(giverMobileNo);
		account.getWallet().setAccountBalance(account.getWallet().getAccountBalance()-amount);
		Account account1=accountEntry.get(gainerMobileNo);
		account1.getWallet().setAccountBalance(account1.getWallet().getAccountBalance()+amount);
		return "your transfer got successfully";
	}
	@Override
	public ArrayList<Transaction> printTransaction(String mobileNo) {
		
		return null;
	}
	
	}
