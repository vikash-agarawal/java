package com.cg.mra.dao;
import java.util.ArrayList;

import com.cg.mra.beans.*;
import com.cg.mra.exception.Accountexception;
public interface AccountDao {
	public Account createAccount(Account account);
	public double showBalance(String mobileNo);
	public double deposit(String mobileNo, double rechargeamount);
	public double withdrow(String mobileNo, double withdrowamount);
	public String fundTransfer(String giverMobileNo, double Amount, String gainerMobileNo);
	public ArrayList<Transaction> printTransaction(String mobileNo);
}
