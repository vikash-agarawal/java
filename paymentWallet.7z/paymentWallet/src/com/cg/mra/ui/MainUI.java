/**
 * 
 */
package com.cg.mra.ui;

import java.util.Scanner;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceimpl;

public class MainUI {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccountService a=new AccountServiceimpl();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("\n Enter1 for creating Account..\n Enter 2 for Deposit.. \n Enter "
					+ "3 for Withdrowal..\n Enter 4 for Fund Transfer..\n Enter 5 for "
					+ "Show Blance..\n Enter 6 for Print Transactions..\n Enter 7 for exit..");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:System.out.println();
			}
		}
	}

}
