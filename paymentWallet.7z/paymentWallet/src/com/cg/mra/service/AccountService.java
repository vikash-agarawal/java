package com.cg.mra.service;
import java.util.ArrayList;

import com.cg.mra.beans.*;
public interface AccountService {
	public Account createAccount(Account account);
	public double showBalance(String mobileNo);
	public double deposit(String mobileNo, double rechargeamount);
	public double withdrow(String mobileNo, double withdrowamount);
	public String fundTransfer(String giverMobileNo, double Amount, String gainerMobileNo);
	public ArrayList<Transaction> printTransaction(String mobileNo);
}
