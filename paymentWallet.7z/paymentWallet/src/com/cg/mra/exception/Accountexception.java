package com.cg.mra.exception;

public class Accountexception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Accountexception(String str) {
		super(str);
		// TODO Auto-generated constructor stub
	}
	
}
