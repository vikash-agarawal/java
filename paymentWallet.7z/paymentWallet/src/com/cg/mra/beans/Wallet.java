package com.cg.mra.beans;

public class Wallet {
	private String mobileNO;
	private double accountBalance;
	public String getMobileNO() {
		return mobileNO;
	}
	public void setMobileNO(String mobileNO) {
		this.mobileNO = mobileNO;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public Wallet(String mobileNO, double accountBalance) {
		super();
		this.mobileNO = mobileNO;
		this.accountBalance = accountBalance;
	}
	public Wallet() {
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(accountBalance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((mobileNO == null) ? 0 : mobileNO.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Wallet other = (Wallet) obj;
		if (Double.doubleToLongBits(accountBalance) != Double.doubleToLongBits(other.accountBalance))
			return false;
		if (mobileNO == null) {
			if (other.mobileNO != null)
				return false;
		} else if (!mobileNO.equals(other.mobileNO))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Wallet [mobileNO=" + mobileNO + ", accountBalance=" + accountBalance + "]";
	}
	
}
