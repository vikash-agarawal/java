package com.cg.mra.beans.util;
import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;
public class AccountUtil {
static Map<String,Account> accountMap=new HashMap<>();
	
	static
{
		accountMap.put(null, null);
}

	public static HashMap<String,Account> getAccountMap() {
		return (HashMap<String, Account>) accountMap;
	}

	public static void setAccountMap(HashMap<String,Account> accountMap) {
		AccountUtil.accountMap = accountMap;
	}

}
